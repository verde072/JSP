<script type="text/javascript">
	alert("왔다");
</script>